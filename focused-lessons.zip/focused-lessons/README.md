# QuietLoom focused Python lessons

These are original teaching examples, not trained industrial models.

## Setup
Use Python 3.12 or newer. In the VS Code terminal:

```powershell
python -m venv .venv
.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
```

On macOS/Linux, activate with `source .venv/bin/activate`.
The accuracy examples use only the Python standard library.

## Follow along
Create `left_bias.py` or `accuracy_trap.py` in your own lesson folder.
Use the numbered `rl/` or `ml/` files to compare your work at each checkpoint.
Run a checkpoint with, for example, `python rl/01_broken_trace.py`.
The root files collect the complete examples with assertions.

RL action order: left, down, right, up. Sampled choices test action selection;
they do not measure learned success. The final RL checkpoint makes DOWN the
greedy favorite. Predict epsilon-zero behavior before opening that solution.

ML labels: zero = healthy, one = faulty. Predictions are hand-set. Precision
is undefined when no alarms are issued and is represented as null.

Full RL workshop: https://www.youtube.com/watch?v=q9UxQozYXwA
Full ML course: https://www.youtube.com/watch?v=10wKlJYPlww

## Exact recorded files
`recorded/` contains the final files typed during the lesson recordings. Run them from the lesson folder with `python recorded/left_bias.py` or `python recorded/accuracy_trap.py`. The RL file intentionally prints the original broken trace before the corrections. `rl/03b_environment_helper.py` runs the random-tie helper inside five actual environment steps. None of these diagnostic steps trains the agent.
