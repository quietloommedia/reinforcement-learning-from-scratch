"""A fictional inspection dataset; these are hand-set predictions, not a trained model."""
import json

def evaluate(actual, predicted):
    assert len(actual)==len(predicted) and len(actual)>0
    tp=sum(a==1 and p==1 for a,p in zip(actual,predicted))
    fn=sum(a==1 and p==0 for a,p in zip(actual,predicted))
    fp=sum(a==0 and p==1 for a,p in zip(actual,predicted))
    tn=sum(a==0 and p==0 for a,p in zip(actual,predicted))
    return dict(tp=tp,fn=fn,fp=fp,tn=tn,accuracy=(tp+tn)/len(actual),
                recall=tp/(tp+fn) if tp+fn else None,
                precision=tp/(tp+fp) if tp+fp else None)

def main():
    actual=[0]*99+[1]  # 0 = healthy, 1 = faulty; known inspection outcomes
    all_healthy=[0]*100
    all_alarm=[1]*100
    selective=[1]*4+[0]*95+[1]  # four false alarms and the true fault
    result={name:evaluate(actual,pred) for name,pred in
            [('all_healthy',all_healthy),('all_alarm',all_alarm),('selective',selective)]}
    assert result['all_healthy']==dict(tp=0,fn=1,fp=0,tn=99,accuracy=.99,recall=0,precision=None)
    assert result['all_alarm']['accuracy']==.01 and result['all_alarm']['recall']==1
    assert result['selective']==dict(tp=1,fn=0,fp=4,tn=95,accuracy=.96,recall=1,precision=.2)
    print(json.dumps({'fictional':True,'machines':100,'faults':1,'policies':result},indent=2))
if __name__=='__main__': main()
