"""CPU-only FrozenLake diagnostic. No renderer, training or GPU libraries."""
import json
import numpy as np
import gymnasium as gym

def greedy_action(row,rng):
    winners=np.flatnonzero(row==row.max())
    return int(rng.choice(winners))

def choose_action(row,epsilon,rng):
    if rng.random()<epsilon:
        return int(rng.integers(len(row)))
    return greedy_action(row,rng)

def main():
    q=np.zeros((16,4))
    env=gym.make('FrozenLake-v1',is_slippery=False)
    state,_=env.reset(seed=7)
    trace=[]
    for _ in range(5):
        previous=state; action=int(np.argmax(q[state]))
        state,reward,terminated,truncated,_=env.step(action)
        trace.append(dict(state=previous,action=action,next_state=state,reward=reward))
        if terminated or truncated: break
    env.close()
    rng=np.random.default_rng(7)
    tied=[greedy_action(q[0],rng) for _ in range(12)]
    row=np.array([0.,0.,.2,0.])
    counts={}
    for eps in (0.,.2):
        rng=np.random.default_rng(7)
        choices=[choose_action(row,eps,rng) for _ in range(1000)]
        counts[str(eps)]=np.bincount(choices,minlength=4).tolist()
    assert all(t['action']==0 and t['next_state']==0 and t['reward']==0 for t in trace)
    assert len(set(tied))>1
    assert counts['0.0']==[0,0,1000,0]
    assert all(c>0 for c in counts['0.2'])
    print(json.dumps(dict(numpy=np.__version__,gymnasium=gym.__version__,
        action_names=['left','down','right','up'],broken_trace=trace,tie_choices=tied,
        unequal_row=row.tolist(),sample_counts=counts,draws_per_condition=1000,
        note='Action-selection samples, not learned success or episode evaluation'),indent=2))
if __name__=='__main__': main()
