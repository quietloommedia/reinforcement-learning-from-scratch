actual = [0] * 99 + [1]  # Known inspection outcomes
predicted = [0] * 100  # Hand-set predictions, not a trained model
accuracy = sum(a == p for a, p in zip(actual, predicted)) / len(actual)
print("accuracy:", accuracy)
