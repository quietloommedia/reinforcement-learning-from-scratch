"""A fictional inspection dataset; these are hand-set predictions, not a trained model."""
import json

def evaluate(actual, predicted):
    assert len(actual)==len(predicted) and len(actual)>0
    tp=sum(a==1 and p==1 for a,p in zip(actual,predicted))
    fn=sum(a==1 and p==0 for a,p in zip(actual,predicted))
    fp=sum(a==0 and p==1 for a,p in zip(actual,predicted))
    tn=sum(a==0 and p==0 for a,p in zip(actual,predicted))
    return dict(tp=tp,fn=fn,fp=fp,tn=tn,accuracy=(tp+tn)/len(actual),
                recall=tp/(tp+fn) if tp+fn else None,
                precision=tp/(tp+fp) if tp+fp else None)

actual = [0] * 99 + [1]
predicted = [1] * 4 + [0] * 95 + [1]
print(json.dumps(evaluate(actual, predicted), indent=2))
