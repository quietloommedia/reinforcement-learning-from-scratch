import numpy as np
import gymnasium as gym

env = gym.make("FrozenLake-v1", is_slippery=False)
q = np.zeros((16, 4))
state, _ = env.reset(seed=7)
for _ in range(5):
    action = int(np.argmax(q[state]))
    state, reward, terminated, truncated, _ = env.step(action)
    print("action", action, "state", state, "reward", reward)
    if terminated or truncated:
        break
env.close()

print("Start row:", q[0])
print("argmax index:", np.argmax(q[0]))
