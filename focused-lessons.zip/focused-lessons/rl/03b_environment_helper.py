import numpy as np
import gymnasium as gym

def greedy_action(row, rng):
    winners = np.flatnonzero(row == row.max())
    return int(rng.choice(winners))

q = np.zeros((16, 4))

# Use the helper in an actual environment loop; no training updates.
env = gym.make("FrozenLake-v1", is_slippery=False)
state, _ = env.reset(seed=7)
rng = np.random.default_rng(7)
for _ in range(5):
    action = greedy_action(q[state], rng)
    state, reward, terminated, truncated, _ = env.step(action)
    print("helper action", action, "state", state, "reward", reward)
    if terminated or truncated:
        break
env.close()
