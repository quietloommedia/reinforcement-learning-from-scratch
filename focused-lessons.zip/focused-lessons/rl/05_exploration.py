import numpy as np
import gymnasium as gym

env = gym.make("FrozenLake-v1", is_slippery=False)
q = np.zeros((16, 4))
state, _ = env.reset(seed=7)
for _ in range(5):
    action = int(np.argmax(q[state]))
    state, reward, terminated, truncated, _ = env.step(action)
    print("action", action, "state", state, "reward", reward)
    if terminated or truncated:
        break
env.close()

def greedy_action(row, rng):
    winners = np.flatnonzero(row == row.max())
    return int(rng.choice(winners))

rng = np.random.default_rng(7)
print("Tied candidates:", np.flatnonzero(q[0] == q[0].max()))
print("Twelve helper samples:", [greedy_action(q[0], rng) for _ in range(12)])

row = np.array([0.0, 0.0, 0.2, 0.0])

def choose_action(row, epsilon, rng):
    if rng.random() < epsilon:
        return int(rng.integers(len(row)))
    return greedy_action(row, rng)

for epsilon in (0.0, 0.2):
    rng = np.random.default_rng(7)
    choices = [choose_action(row, epsilon, rng) for _ in range(1000)]
    counts = np.bincount(choices, minlength=4)
    print("epsilon:", epsilon, "counts [left, down, right, up]:", counts)
